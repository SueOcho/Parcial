//
//  ViewController.swift
//  Parcial
//
//  Created by user179030 on 10/22/20.
//

import UIKit

class ViewController: UIViewController {

    @objc func tapGestureInView() {
        print("CERRAR TECLADO ACCION")
        self.view.endEditing(true)

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillShow(_:)),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillHide(_:)),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        print("EL TECLADO APARECE")
        
        let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect ?? .zero
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        print(keyboardFrame)
        print(animationDuration)
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        print("El TECLADO SE OCULTA")
    }
    
    
    /////////////////////////////////////////////
    @IBOutlet weak var LoreLabel: UILabel!
    @IBAction func btnMostrar(_ sender: Any) {
        let widthLore=LoreLabel.frame.size.width
        let heightLore=LoreLabel.frame.size.height
        let xLore = LoreLabel.frame.origin.x
        let yLore = LoreLabel.frame.origin.y

        LoreLabel.frame.size.height = 40
        print(widthLore )
        print(heightLore)
        print(xLore)
        print(yLore)

        
        LoreLabel.frame =  CGRect(x:xLore, y: yLore, width:widthLore, height:heightLore-100)

        //let frame = CGRect(x: 1000, y:200 ,width:widthLore, height: 100)
        
        
    }
}





