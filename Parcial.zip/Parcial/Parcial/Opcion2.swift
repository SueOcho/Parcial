//
//  Opcion2.swift
//  Parcial
//
//  Created by user179030 on 10/22/20.
//


import UIKit

class Opcion2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    let width = self.view.frame.width
    let height = self.view.frame.height
    
    let posx = CGFloat.random(in: 40...width-40)
    let posy = CGFloat.random(in: 150...height-150)
    
    let frame = CGRect(x: posx, y: posy, width: 80, height: 80)
    let boxView = BoxView(frame: frame)
    self.view.addSubview(boxView)
    boxView.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
}
extension Opcion2: BoxViewDelegate {
    
    func boxViewTapInView(_ view: BoxView) {
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.2, options: .curveEaseInOut, animations: {
            
//            view.changeRandomBackgroundColor()
            view.changeRandomCenter()
            view.changeAngleRotation()
            
        }) { (_) in
            
            view.transform = .identity
            print("Termino la animación")
        }
    }
}
